package Shapes;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

public class Canvas {
    private static Canvas canvasSingleton;

    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("BlueJ Shapes Demo", 4000, 4000, 
                                         Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;

    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<>();
        shapes = new HashMap<>();
    }

    public void setVisible(boolean visible) {
        if (graphic == null) {
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D) canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    public void draw(Object referenceObject, String color, java.awt.Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }

    public void setForegroundColor(String colorString) {
        switch (colorString) {
            case "red" -> graphic.setColor(Color.red);
            case "black" -> graphic.setColor(Color.black);
            case "blue" -> graphic.setColor(Color.blue);
            case "yellow" -> graphic.setColor(Color.yellow);
            case "green" -> graphic.setColor(Color.green);
            case "magenta" -> graphic.setColor(Color.magenta);
            case "white" -> graphic.setColor(Color.white);
            case "cyan" -> graphic.setColor(Color.cyan);
            case "orange" -> graphic.setColor(Color.orange);
            case "gray" -> graphic.setColor(Color.gray);
            case "darkGray" -> graphic.setColor(Color.darkGray);
            case "lightGray" -> graphic.setColor(Color.lightGray);
            case "pink" -> graphic.setColor(Color.pink);
            case "brown" -> graphic.setColor(new Color(139, 69, 19));
            case "purple" -> graphic.setColor(new Color(128, 0, 128));
            case "navy" -> graphic.setColor(new Color(0, 0, 128));
            case "olive" -> graphic.setColor(new Color(128, 128, 0));
            case "teal" -> graphic.setColor(new Color(0, 128, 128));
            case "maroon" -> graphic.setColor(new Color(128, 0, 0));
            case "gold" -> graphic.setColor(new Color(255, 215, 0));
            case "salmon" -> graphic.setColor(new Color(250, 128, 114));
            case "violet" -> graphic.setColor(new Color(238, 130, 238));
            case "indigo" -> graphic.setColor(new Color(75, 0, 130));
            case "turquoise" -> graphic.setColor(new Color(64, 224, 208));
            case "lime" -> graphic.setColor(new Color(0, 255, 0));
            case "orchid" -> graphic.setColor(new Color(218, 112, 214));
            case "crimson" -> graphic.setColor(new Color(220, 20, 60));
            case "coral" -> graphic.setColor(new Color(255, 127, 80));
            case "khaki" -> graphic.setColor(new Color(240, 230, 140));
            case "lavender" -> graphic.setColor(new Color(230, 230, 250));
            case "beige" -> graphic.setColor(new Color(245, 245, 220));
            case "azure" -> graphic.setColor(new Color(240, 255, 255));
            case "chartreuse" -> graphic.setColor(new Color(127, 255, 0));
            case "peru" -> graphic.setColor(new Color(205, 133, 63));
            case "slateGray" -> graphic.setColor(new Color(112, 128, 144));
            case "seagreen" -> graphic.setColor(new Color(46, 139, 87));
            case "tomato" -> graphic.setColor(new Color(255, 99, 71));
            case "deepPink" -> graphic.setColor(new Color(255, 20, 147));
            case "forestGreen" -> graphic.setColor(new Color(34, 139, 34));
            case "midnightBlue" -> graphic.setColor(new Color(25, 25, 112));
            case "rosyBrown" -> graphic.setColor(new Color(188, 143, 143));
            case "firebrick" -> graphic.setColor(new Color(178, 34, 34));
            case "dodgerBlue" -> graphic.setColor(new Color(30, 144, 255));
            case "sienna" -> graphic.setColor(new Color(160, 82, 45));
            case "plum" -> graphic.setColor(new Color(221, 160, 221));
            case "lightCoral" -> graphic.setColor(new Color(240, 128, 128));
            case "mediumSeaGreen" -> graphic.setColor(new Color(60, 179, 113));
            case "steelBlue" -> graphic.setColor(new Color(70, 130, 180));
            case "deepSkyBlue" -> graphic.setColor(new Color(0, 191, 255));
            case "springGreen" -> graphic.setColor(new Color(0, 255, 127));
            case "goldenRod" -> graphic.setColor(new Color(218, 165, 32));
            default -> graphic.setColor(Color.black);
        }
    }

    public void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) {
        }
    }

    private void redraw() {
        erase();
        for (Iterator i = objects.iterator(); i.hasNext(); ) {
            shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }

    private void erase() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }

    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    private class ShapeDescription {
        private java.awt.Shape shape;
        private String colorString;

        public ShapeDescription(java.awt.Shape shape, String color) {
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.draw(shape);
            graphic.fill(shape);
        }
    }
}
