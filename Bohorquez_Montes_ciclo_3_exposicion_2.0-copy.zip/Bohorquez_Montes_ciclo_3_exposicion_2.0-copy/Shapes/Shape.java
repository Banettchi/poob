package Shapes;


import java.awt.*;

/**
 * Clase abstracta que define las propiedades y comportamiento básico de una figura geométrica.
 * 
 * <p>Las figuras pueden moverse, cambiar de color y alternar su visibilidad. 
 * Las clases que hereden de `Shape` deben implementar los métodos `draw` y `erase`.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public abstract class Shape {
    // Posición X de la figura en el tablero
    protected int xPosition;

    // Posición Y de la figura en el tablero
    protected int yPosition;

    // Color de la figura
    protected String color;

    // Indica si la figura es visible
    protected boolean isVisible;

    /**
     * Constructor de la clase `Shape`.
     * 
     * @param x      Posición inicial en X.
     * @param y      Posición inicial en Y.
     * @param color  Color de la figura.
     */
    public Shape(int x, int y, String color) {
        this.xPosition = x;
        this.yPosition = y;
        this.color = color;
        this.isVisible = false;
    }

    /**
     * Hace visible la figura y la dibuja en el tablero.
     */
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible la figura y la borra del tablero.
     */
    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    /**
     * Mueve la figura horizontalmente en la distancia especificada.
     * 
     * @param distance Distancia en píxeles que se moverá la figura en el eje X.
     */
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve la figura verticalmente en la distancia especificada.
     * 
     * @param distance Distancia en píxeles que se moverá la figura en el eje Y.
     */
    public void moveVertical(int distance) {
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Cambia el color de la figura.
     * 
     * @param newColor Nuevo color de la figura.
     */
    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }

    /**
     * Método abstracto para dibujar la figura.
     * <p>Debe ser implementado por las clases que hereden de `Shape`.</p>
     */
    protected abstract void draw();

    /**
     * Método abstracto para borrar la figura.
     * <p>Debe ser implementado por las clases que hereden de `Shape`.</p>
     */
    protected abstract void erase();
}
