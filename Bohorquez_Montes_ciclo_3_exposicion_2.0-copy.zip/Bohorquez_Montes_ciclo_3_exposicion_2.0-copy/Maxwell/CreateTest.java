package Maxwell;


import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de pruebas unitarias para la clase {@code Create}.
 * 
 * <p>Se validan diferentes aspectos del tablero, incluyendo la estructura de las cámaras, la división,
 * los tamaños relativos y la visibilidad.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class CreateTest {
    private Create board; // Instancia del tablero para pruebas

    /**
     * Configuración previa a cada prueba.
     * <p>Se ejecuta antes de cada método de prueba para inicializar el tablero con dimensiones predefinidas.</p>
     */
    @Before
    public void setUp() {
        board = new Create(600, 300); // Crea un tablero de 600x300
    }

    /**
     * Verifica que existan dos cámaras en el tablero.
     * <p>Las cámaras son los espacios a cada lado de la división central.</p>
     */
    @Test
    public void shouldHaveTwoChambers() {
        assertNotNull(board.getLeftChamberMinX()); // Verifica que la cámara izquierda tenga un límite definido
        assertNotNull(board.getRightChamberMinX()); // Verifica que la cámara derecha tenga un límite definido
    }

    /**
     * Verifica que las cámaras sean más pequeñas que el fondo del tablero.
     * <p>Las cámaras deben ocupar menos espacio que la mitad del tablero en ancho y altura.</p>
     */
    @Test
    public void chambersShouldBeSmallerThanBorders() {
        int chamberWidth = board.getLeftChamberMaxX() - board.getLeftChamberMinX();
        assertTrue(chamberWidth < board.getWidth() / 2);

        int chamberHeight = board.getChamberMaxY() - board.getChamberMinY();
        assertTrue(chamberHeight < board.getHeight());
    }

    /**
     * Verifica que la división roja esté centrada en el tablero.
     * <p>La división debe estar posicionada en el centro del eje X.</p>
     */
    @Test
    public void divisionShouldBeCentered() {
        int expectedX = board.getCenterX() - (board.getDivisionWidth() / 2);
        assertEquals(expectedX, board.getDivisionX());
    }

    /**
     * Verifica que la altura de la división sea la mitad del fondo del tablero.
     */
    @Test
    public void divisionShouldBeHalfOfBoard() {
        assertEquals(board.getDivisionHeight(), board.getHeight() - 10);
    }

    /**
     * Verifica que ambas cámaras tengan el mismo tamaño.
     * <p>La cámara izquierda y la derecha deben tener el mismo ancho y alto.</p>
     */
    @Test
    public void chambersShouldHaveSameSize() {
        int leftWidth = board.getLeftChamberMaxX() - board.getLeftChamberMinX();
        int rightWidth = board.getRightChamberMaxX() - board.getRightChamberMinX();
        assertEquals(leftWidth, rightWidth);

        int leftHeight = board.getChamberMaxY() - board.getChamberMinY();
        int rightHeight = board.getChamberMaxY() - board.getChamberMinY();
        assertEquals(leftHeight, rightHeight);
    }

    /**
     * Verifica que la clase {@code Create} tenga los métodos de visibilidad `makeVisible()` y `makeInvisible()`.
     * <p>No podemos verificar visualmente el resultado, pero la llamada a los métodos no debe fallar.</p>
     */
    @Test
    public void shouldHaveVisibilityMethods() {
        board.makeInvisible(); 
        board.makeVisible();
    }
}
