package Maxwell;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/**
     * Clase que representa un agujero negro en movimiento dentro del simulador de Maxwell.
     *
     * <p>Los agujeros negros móviles rebotan en los bordes del tablero y en la división central.
     * Su movimiento se puede iniciar o detener globalmente mediante {@link #startMoving(int)} y {@link #stopMoving()}.</p>
     *
     * <p>Una vez colisionan con un borde o la división, se detienen completamente.</p>
     *
     * <p>Los objetos de esta clase se registran automáticamente en una lista estática para facilitar
     * el control grupal de movimiento.</p>
     * 
     * <p>Hereda de {@link Hole}.</p>
     * 
     * @author Juan Carlos y Diego Montes
     * @version 1.0
     */
public class MovingHole extends Hole {
    private int vx; // Velocidad en X
    private int vy; // Velocidad en Y
    private Create board; // Referencia al tablero
    public static int ticks = 0;
    private static final List<MovingHole> movingHoles = new ArrayList<>();


    
    public MovingHole(Create board, int px, int py, int vx, int vy, int size) {
        super(px, py, size);
        this.board = board;
        this.vx = vx;
        this.vy = vy;
        makeVisible();
        movingHoles.add(this);
    }

    
    /**
     * Constructor alterno para herencia o creación simple.
     *
     * @param px   Posición inicial en X.
     * @param py   Posición inicial en Y.
     * @param size Tamaño del agujero.
     */
    public MovingHole(int px, int py, int size) {
        super(px, py, size);
    }

    
    /**
     * Inicia el movimiento de todos los agujeros negros móviles registrados.
     *
     * <p>Si un agujero tenía velocidad cero, se le asigna una velocidad mínima de 1 en cada dirección.</p>
     *
     * @param tickCount Cantidad de ciclos o ticks que durará el movimiento.
     */
    public static void startMoving(int tickCount) {
        ticks = tickCount;
        
        for (MovingHole mHole : movingHoles) {
            if (mHole.vx == 0) mHole.vx = 1;
            if (mHole.vy == 0) mHole.vy = 1;
        }
    }

    
    /**
     * Detiene el movimiento de todos los agujeros móviles.
     *
     * <p>Esto pone {@code ticks = 0}, indicando que ningún agujero debe continuar moviéndose.</p>
     */
    public static void stopMoving() {
        ticks = 0; //  Detener el movimiento
    }
    
    
    /**
     * Mueve el agujero negro dentro del tablero, rebotando en bordes o deteniéndose en la división.
     *
     * <p>Si el agujero colisiona con los límites del tablero o con la división central,
     * su movimiento se detiene por completo (vx = 0, vy = 0).</p>
     *
     * @param board Instancia del tablero sobre el cual se ejecuta el movimiento.
     */
    public void move(Create board) {
        erase(); // Borra la posición anterior
    
        int divisionX = board.getDivisionX();
        int boardWidth = board.getWidth();
        int boardHeight = board.getHeight();
    
        // Nueva posición tentativa
        int newX = getX() + vx;
        int newY = getY() + vy;
    
        //  Detectar colisión con los bordes
        boolean touchingHorizontalWall = 
            (vx > 0 && newX + holeSize >= boardWidth) || // Pared derecha
            (vx < 0 && newX <= 0);                      // Pared izquierda
    
        boolean touchingVerticalWall = 
            (vy > 0 && newY + holeSize >= boardHeight) || // Pared inferior
            (vy < 0 && newY <= 0);                       // Pared superior
    
        boolean touchingDivision = false;
        
        //  Solo detenerse en la división si viene del otro lado
        if (vx > 0 && getX() < divisionX && newX + holeSize >= divisionX) { 
            touchingDivision = true; // Viene de la izquierda
        } 
        if (vx < 0 && getX() > divisionX && newX <= divisionX) { 
            touchingDivision = true; // Viene de la derecha
        }
    
        //  Si toca un borde, detenerse completamente
        if (touchingDivision || touchingHorizontalWall || touchingVerticalWall) {
            vx = 0;
            vy = 0;
            return; // 🚨 Detenerse inmediatamente
        }
    
        //  Mueve la figura visualmente
        moveShape(vx, vy);
    
        // Actualiza posición interna
        px = newX;
        py = newY;
    
        draw(); // Redibujar
    }

}