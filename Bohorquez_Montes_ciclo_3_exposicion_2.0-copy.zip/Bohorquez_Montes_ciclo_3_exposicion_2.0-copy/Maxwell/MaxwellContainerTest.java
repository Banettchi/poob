package Maxwell;


import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.List;

/**
 * Pruebas unitarias para la clase {@code MaxwellContainer}.
 *
 * <p>Se validan la correcta inicialización del simulador, manipulación de demonios y partículas,
 * cambios de visibilidad y el funcionamiento de la simulación.</p>
 *
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class MaxwellContainerTest {
    private MaxwellContainer simulator;

    /**
     * Configuración previa a cada prueba.
     * <p>Inicializa un simulador con un tablero de dimensiones arbitrarias.</p>
     */
    @Before
    public void setUp() {
        simulator = new MaxwellContainer(500, 300);
    }

    /**
     * Verifica que el simulador se inicializa correctamente.
     */
    @Test
    public void shouldInitializeSimulator() {
        assertNotNull(simulator.getBoard());
        assertTrue(simulator.ok());
    }

    /**
     * Verifica que se puedan agregar y eliminar demonios.
     */
    @Test
    public void shouldManageDemons() {
        int initialCount = simulator.getDemons().size();

        simulator.addDemon(150);
        assertFalse(simulator.getDemons().isEmpty());

        simulator.delDemon(1);
        assertEquals(initialCount, simulator.getDemons().size());
    }

    /**
     * Verifica que se puedan agregar y eliminar partículas.
     */
    @Test
    public void shouldManageParticles() {
        int initialCount = simulator.getParticles().size();
        System.out.println("Partículas iniciales: " + initialCount);  // 🧐 Imprime el conteo inicial
    
        simulator.addParticle("red", true, 100, 100, 5, 5);
        System.out.println("Después de agregar: " + simulator.getParticles().size());  // 🔍 Debe ser initialCount + 1
        assertFalse(simulator.getParticles().isEmpty());
    
        simulator.delParticle();
        System.out.println("Después de eliminar: " + simulator.getParticles().size());  // 🔎 ¿Se eliminó correctamente?
    
        assertEquals(initialCount, simulator.getParticles().size());
    }


    /**
     * Verifica que el simulador cambia su visibilidad sin errores.
     */
    @Test
    public void shouldToggleVisibility() {
        simulator.makeInvisible();
        assertTrue(simulator.ok());

        simulator.makeVisible();
        assertTrue(simulator.ok());
    }
}
