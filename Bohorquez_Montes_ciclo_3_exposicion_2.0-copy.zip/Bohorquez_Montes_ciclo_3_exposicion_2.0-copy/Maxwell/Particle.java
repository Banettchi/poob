package Maxwell;

import Shapes.Circle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Representa una partícula dentro del simulador de Maxwell.
 * 
 * <p>
 * Cada partícula tiene un color, velocidad y posición, y puede desplazarse por el
 * tablero simulando colisiones con paredes, el demonio y agujeros negros.
 * </p>
 * 
 * <p>
 * Las partículas pueden ser absorbidas por agujeros negros, cruzar divisiones
 * si el demonio lo permite, y se actualizan en cada ciclo del simulador.
 * </p>
 * 
 * <p>
 * También se gestionan globalmente mediante una lista estática que permite 
 * controlar todas las partículas existentes en el simulador.
 * </p>
 * 
 * @author Juan Carlos Bohorquez
 * @author Diego Montes
 * @version 1.0
 */

public class Particle extends BoardElement {
    
    // Número de actualizaciones por cada tick de movimiento
    private static final int updatesPerTick = 10;

    // Contador de ticks para controlar la duración del movimiento
    public static int ticks = 0;
    
    // Generador de números aleatorios para decidir el cruce con el demonio
    public static final Random random_2 = new Random();
    
    // Tamaño de la partícula
    private static final int particleSize = 10;

    // Margen de seguridad dentro de la cámara
    private static final int margin = 2;

    // Número máximo de partículas permitidas en el simulador
    public static final int maxParticles = 50;

    // Velocidad máxima de las partículas
    public static final int speed = 5;

    // Colores disponibles para las partículas
    public static final String[] colors = {
        "red", "black", "blue", "yellow", "green", "magenta", "cyan", "orange",
        "gray", "darkGray", "lightGray", "pink", "brown", "purple", "navy", "olive",
        "teal", "maroon", "gold", "salmon", "violet", "indigo", "turquoise", "lime",
        "orchid", "crimson", "coral", "khaki", "lavender", "beige", "azure",
        "chartreuse", "peru", "slateGray", "seagreen", "tomato", "deepPink",
        "forestGreen", "midnightBlue", "rosyBrown", "firebrick", "dodgerBlue",
        "sienna", "plum", "lightCoral", "mediumSeaGreen", "steelBlue",
        "deepSkyBlue", "springGreen", "goldenRod"
    };

    // Generador de números aleatorios
    private static final Random random = new Random();
    

    // Lista de todas las partículas activas en el simulador
    public static final List<Particle> particles = new ArrayList<>();

    // Representación gráfica de la partícula
    public Circle shape;

    // Color de la partícula
    private String color;

    // Indica si la partícula es roja (true) o azul (false)
    public boolean isRed;

    // Velocidad en X e Y de la partícula
    public int vx;
    public int vy;
    
    // Indica si la partícula ha sido absorbida
    private boolean absorbed;
    
    protected boolean canBeAbsorbed = true;

    /**
     * Constructor de la clase Particle.
     * 
     * @param color  Color de la partícula.
     * @param isRed  true si la partícula es roja, false si es azul.
     * @param px     Posición en X de la partícula.
     * @param py     Posición en Y de la partícula.
     * @param vx     Velocidad en X de la partícula.
     * @param vy     Velocidad en Y de la partícula.
     * @param board  Tablero donde se encuentra la partícula.
     */
    public Particle(String color, boolean isRed, int px, int py, int vx, int vy, Create board) {
        super(px, py);
        this.color = color;
        this.isRed = isRed;
        this.vx = vx;
        this.vy = vy;
        this.absorbed = false;

        shape = new Circle();
        shape.changeSize(particleSize);
        shape.moveHorizontal(px);
        shape.moveVertical(py);
        shape.changeColor(color);

    }

    /**
     * Dibuja la partícula en el tablero.
     */
    @Override
    protected void draw() {
        if (!absorbed) {
            shape.makeVisible();
        }
    }

    /**
     * Borra la partícula del tablero.
     */
    @Override
    protected void erase() {
        shape.makeInvisible();
    }

    /**
     * Mueve la partícula en el tablero actualizando su posición.
     * 
     * @param board  Tablero donde se encuentra la partícula.
     * @param newVx  Nueva velocidad en X.
     * @param newVy  Nueva velocidad en Y.
     */
    public void move(Create board, int newVx, int newVy) {
        erase();

        // Actualizamos velocidad
        vx = newVx;
        vy = newVy;

        // Actualizamos posición
        px += vx;
        py += vy;

        // Movemos la partícula en el canvas
        shape.moveHorizontal(vx);
        shape.moveVertical(vy);

        draw();
    }

    /**
     * Obtiene la velocidad en X de la partícula.
     * @return Velocidad en X.
     */
    public int getVx() {
        return vx;
    }

    /**
     * Obtiene la velocidad en Y de la partícula.
     * @return Velocidad en Y.
     */
    public int getVy() {
        return vy;
    }

    /**
     * Obtiene el color de la partícula.
     * @return Color de la partícula.
     */
    public String getColor() {
        return color;
    }

    /**
     * Verifica si la partícula es roja.
     * @return true si la partícula es roja, false si es azul.
     */
    public boolean isRed() {
        return isRed;
    }
        
    /**
     * Marca la partícula como absorbida.
     * 
     * @param absorbed Estado de absorción.
     */
    public void setAbsorbed(boolean absorbed) {
        this.absorbed = absorbed;
    }

    /**
     * Verifica si la partícula ha sido absorbida.
     * 
     * @return true si está absorbida, false si no.
     */
    public boolean isAbsorbed() {
        return absorbed;
    }


    /**
     * Devuelve la lista de partículas activas en el simulador.
     * @return Lista de partículas activas.
     */
    public static List<Particle> getParticles() {
        return particles;
    }

    /**
     * Establece una nueva posición para la partícula sin cambiar su velocidad.
     * 
     * @param newX Nueva coordenada X.
     * @param newY Nueva coordenada Y.
     */
    public void setPosition(int newX, int newY) {
        erase(); // Borra la partícula antes de moverla
        this.px = newX;
        this.py = newY;
        draw(); // La redibuja en la nueva posición
    }

    /**
     * Obtiene la posición en X de la partícula.
     * @return Posición en X.
     */
    public int getPx() {
        return px;
    }
    
    /**
     * Obtiene la posición en Y de la partícula.
     * @return Posición en Y.
     */
    public int getPy() {
        return py;
    }

    /**
     * Inicia el movimiento de las partículas por el número de ticks especificado.
     * 
     * @param board      Tablero del simulador.
     * @param tickCount  Número de ticks antes de detener el movimiento.
     */
    public static void startMoving(Create board, int tickCount) {
        ticks = tickCount;
        while (ticks > 0) {
            for (int i = 0; i < updatesPerTick; i++) {
                updateMovement(board);
            }
            ticks--;
        }
    }

    /**
     * Detiene el movimiento de todas las partículas en el simulador.
     */
    public static void stopMoving() {
        ticks = 0;
    }

    /**
     * Actualiza el movimiento de todas las partículas en el tablero.
     *
     * @param board Tablero del simulador.
     */
    public static void updateMovement(Create board) {
        if (ticks <= 0) return;
    
        // Verificar colisiones con agujeros negros antes de mover partículas
        for (Hole hole : Hole.getHoles()) {  // Iterar sobre los agujeros negros
            hole.checkCollisions(Particle.getParticles());
        }
        
        // Mover cada partícula en el tablero
        for (Particle particle : Particle.getParticles()) {
            if (!particle.isAbsorbed()) { // Solo mueve las que no fueron absorbidas
                particle.moveParticle(particle, board);
            }
        }
    
        // Remover partículas absorbidas después del movimiento
        Particle.getParticles().removeIf(Particle::isAbsorbed);
    }

    /**
     * Mueve una partícula y maneja sus colisiones con paredes, división y demonio.
     * 
     * @param particle Partícula a mover.
     * @param board    Tablero del simulador.
     */
    protected void moveParticle(Particle particle, Create board) {
        int newX = particle.getX() + particle.getVx();
        int newY = particle.getY() + particle.getVy();
        int newVx = particle.getVx();
        int newVy = particle.getVy();
        
        int divisionX = board.getDivisionX();
        int divisionWidth = board.getDivisionWidth();
        int leftLimit = board.getLeftChamberMinX();
        int rightLimit = board.getRightChamberMaxX();
    
        boolean wasLeftChamber = particle.getX() < divisionX;
        boolean isLeftChamber = newX < divisionX;
    
        // **1. Verificar si la partícula cruza la división**
        boolean crossingDivision = (wasLeftChamber && !isLeftChamber) || (!wasLeftChamber && isLeftChamber);
        
        if (crossingDivision) {
            boolean passed = Demon.handleDemonCollision(particle, board);
            if (!passed) {
                // Rebote si el demonio no permite el paso
                newVx = -newVx;
                newX = particle.getX() + newVx;  // Corregir la posición para evitar que atraviese
            }
        }
    
        // **2. Verificar colisión con los bordes de la cámara**
        if (isLeftChamber) {
            if (newX <= leftLimit) {
                newVx = Math.abs(newVx); // Rebote en la pared izquierda
                newX = leftLimit; // Ajustar posición
            }
        } else {
            if (newX >= rightLimit) {
                newVx = -Math.abs(newVx); // Rebote en la pared derecha
                newX = rightLimit; // Ajustar posición
            }
        }
    
        // **3. Rebote en el techo y el piso**
        if (newY <= board.getTopLimit() || newY >= board.getBottomLimit()) {
            newVy = -newVy;
            newY = Math.max(board.getTopLimit(), Math.min(newY, board.getBottomLimit())); // Ajuste de posición
        }
    
        // **4. Aplicar movimiento**
        particle.move(board, newVx, newVy);
    }

    protected Random getRandom() {
        return random_2;
    }
}