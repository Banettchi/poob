package Maxwell;

import Shapes.Circle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Clase que representa un agujero negro dentro del simulador de Maxwell.
 * 
 * <p>Los agujeros negros pueden absorber partículas y se pueden agregar o eliminar.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.2
 */
public class Hole extends BoardElement {
    private Circle shape;
    public int holeSize;
    public static final List<Hole> holes = new ArrayList<>();
    private final List<Particle> absorbedParticles = new ArrayList<>();

    /**
     * Constructor de la clase Hole.
     * 
     * @param px Posición X del agujero.
     * @param py Posición Y del agujero.
     * @param size Tamaño del agujero.
     */
    public Hole(int px, int py, int size) {
        super(px, py);
        this.holeSize = size;

        shape = new Circle();
        shape.changeSize(size);
        shape.moveHorizontal(px);
        shape.moveVertical(py);
        shape.changeColor("black");

        holes.add(this);
    }

    @Override
    protected void draw() {
        shape.makeVisible();
    }

    @Override
    protected void erase() {
        shape.makeInvisible();
    }

    /**
     * Verifica si una partícula está dentro del agujero negro.
     * 
     * @param particle Partícula a verificar.
     * @return true si la partícula está dentro, false si no.
     */
    public boolean isParticleInside(Particle particle) {
        int particleX = particle.getPx();
        int particleY = particle.getPy();
        int radius = holeSize / 2; // Radio de absorción basado en el tamaño

        return Math.abs(particleX - px) < radius && Math.abs(particleY - py) < radius;
    }

    /**
     * Establece una nueva posición para el agujero.
     * 
     * @param x Nueva posición X.
     * @param y Nueva posición Y.
     */
    public void setPosition(int x, int y) {
        move(x - getX(), y - getY()); // Usa el método `move` de `BoardElement`
    }
    
    /**
     * Absorbe una partícula haciéndola invisible.
     * 
     * @param particle Partícula a absorber.
     */
    public void absorbParticle(Particle particle) {
        if (!particle.canBeAbsorbed) {
            return; // No hacer nada si la partícula no puede ser absorbida.
        }
        
        if (!absorbedParticles.contains(particle)) {
            absorbedParticles.add(particle);
            particle.setAbsorbed(true); // Marca la partícula como absorbida
            particle.makeInvisible();   // Se oculta visualmente
        }
    }    
    
    /**
     * Verifica todas las partículas y absorbe las que entren en contacto con el agujero.
     * Solo las oculta y las elimina al final del tick.
     * 
     * @param particles Lista de partículas en la simulación.
     */
    protected void checkCollisions(List<Particle> particles) {
        for (Particle particle : particles) {
            if (!particle.isAbsorbed()) { // Solo revisa las que aún existen
                for (Hole hole : holes) {
                    if (hole.isParticleInside(particle)) {
                        hole.absorbParticle(particle);
                    }
                }
            }
        }

        // Elimina las partículas absorbidas al final del tick
        particles.removeIf(Particle::isAbsorbed);
    }
    
    public void moveShape(int dx, int dy) {
        shape.moveHorizontal(dx);
        shape.moveVertical(dy);
    }
    
    /**
     * Devuelve la lista de agujeros negros creados en el simulador.
     * @return Lista de agujeros negros.
     */
    public static List<Hole> getHoles() {
        return holes;
    }

    /**
     * Obtiene la lista de partículas absorbidas por este agujero negro.
     * 
     * @return Lista de partículas absorbidas.
     */
    public List<Particle> getAbsorbedParticles() {
        return absorbedParticles;
    }
    
    /**
     * Método para mover el agujero (sobreescrito en MovingHole).
     */
    public void move() {
        // Vacio para sobreescribir en otras clases
    }
}