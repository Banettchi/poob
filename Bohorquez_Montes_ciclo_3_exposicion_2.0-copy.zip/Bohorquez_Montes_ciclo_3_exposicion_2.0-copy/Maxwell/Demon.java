package Maxwell;

import Shapes.Triangle;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase base que representa un demonio en el simulador de Maxwell.
 * 
 * <p>Los demonios controlan el paso de partículas entre las cámaras del simulador.
 * Cada demonio tiene una forma triangular y puede tener diferentes reglas de paso, 
 * dependiendo de su subclase.</p>
 * 
 * <p>Por defecto, el demonio permite el paso de cualquier partícula.</p>
 * 
 * <p>Esta clase también mantiene un registro estático de todos los demonios presentes en el tablero.</p>
 * 
 * @author Juan Carlo
 * @author Diego Montes
 * @version 1.0
 */
public class Demon extends BoardElement {
    public Triangle shape;
    private static final int size = 20;
    public static final List<Demon> demons = new ArrayList<>();

    /**
     * Constructor de la clase Demon.
     *
     * @param px Posición X del demonio.
     * @param py Posición Y del demonio.
     */
    public Demon(int px, int py) {
        super(px, py);
        shape = new Triangle();
        shape.changeSize(size, size);
        shape.moveHorizontal(px - size / 2);
        shape.moveVertical(py - size / 2);
        shape.changeColor("blue");
        demons.add(this); // Se añade a la lista global de demonios
    }

    /**
     * Dibuja visualmente al demonio en el tablero.
     */
    @Override
    protected void draw() {
        shape.makeVisible();
    }

    /**
     * Elimina visualmente al demonio del tablero.
     */
    @Override
    protected void erase() {
        shape.makeInvisible();
    }

    /**
     * Maneja las colisiones entre partículas y demonios.
     * 
     * <p>Si una partícula colisiona con un demonio, este decide si la deja pasar
     * según su implementación específica de {@code canPass()}.</p>
     * 
     * @param particle La partícula que se está moviendo.
     * @param board El tablero donde ocurre la simulación.
     * @return {@code true} si la partícula fue transferida al otro lado; {@code false} si rebotó.
     */
    public static boolean handleDemonCollision(Particle particle, Create board) {
        for (Demon demon : Demon.getDemons()) {
            int demonX = demon.getX();
            int demonY = demon.getY();
            int demonSize = 30;

            boolean collidesWithDemon =
                (particle.getX() >= demonX - demonSize / 2 && particle.getX() <= demonX + demonSize / 2) &&
                (particle.getY() >= demonY - demonSize / 2 && particle.getY() <= demonY + demonSize / 2);

            if (collidesWithDemon) {
                boolean letsPass = demon.canPass(particle); // Cada demonio decide si deja pasar

                if (letsPass) {
                    // Se mueve al otro lado de la división
                    int newX = (particle.getX() < board.getDivisionX()) 
                             ? board.getRightChamberMinX() + 1  
                             : board.getLeftChamberMaxX() - 1;

                    particle.setPosition(newX, particle.getY());
                    particle.move(board, particle.getVx(), particle.getVy()); 
                    return true;
                } else {
                    // Rebota en el demonio
                    particle.move(board, -particle.getVx(), particle.getVy());
                }
            }
        }
        return false;
    }

    /**
     * Devuelve la lista global de demonios presentes en el simulador.
     *
     * @return Lista de objetos {@code Demon}.
     */
    public static List<Demon> getDemons() {
        return demons;
    }

    /**
     * Determina si una partícula puede pasar a través del demonio.
     * 
     * <p>Este método está diseñado para ser sobrescrito por las subclases que
     * definen reglas específicas de paso.</p>
     *
     * @param particle La partícula que intenta cruzar.
     * @return {@code true} si se permite el paso; {@code false} en caso contrario.
     */
    public boolean canPass(Particle particle) {
        return true;  // Comportamiento por defecto
    }
}
