package Maxwell;

/**
 * Clase que representa un demonio débil en el simulador de Maxwell.
 * 
 * <p>El {@code WeakDemon} permite el paso de una única partícula.
 * Luego de dejar pasar una partícula, se vuelve invisible y se elimina del simulador.</p>
 *
 * <p>Visualmente se representa con el color gris.</p>
 *
 * <p>Hereda de {@link Demon}.</p>
 * 
 * @author Juan Carlo
 * @author Diego Montes
 * @version 1.0
 */
public class WeakDemon extends Demon {
    private boolean hasPassed;

    /**
     * Constructor que crea un demonio débil en una posición específica del tablero.
     *
     * @param px Posición X del demonio.
     * @param py Posición Y del demonio.
     */
    public WeakDemon(int px, int py) {
        super(px, py);
        shape.changeColor("gray"); // Se representa con color gris
        hasPassed = false;
    }

    /**
     * Determina si una partícula puede pasar a través del demonio.
     * 
     * <p>Permite el paso solo a una partícula. Después de eso, el demonio se elimina
     * del tablero y no permite más pasos.</p>
     *
     * @param particle La partícula que intenta pasar.
     * @return {@code true} si aún no ha pasado ninguna partícula; {@code false} en caso contrario.
     */
    @Override
    public boolean canPass(Particle particle) {
        if (!hasPassed) {
            hasPassed = true;
            makeInvisible();          // Se vuelve invisible
            demons.remove(this);      // Se elimina del sistema
            return true;
        }
        return false;
    }
}
