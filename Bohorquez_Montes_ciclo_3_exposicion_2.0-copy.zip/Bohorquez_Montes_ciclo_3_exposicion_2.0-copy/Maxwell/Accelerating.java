package Maxwell;

/**
 * Representa una partícula que aumenta su velocidad con cada colisión.
 *
 * <p>Si alcanza el límite de velocidad, mantiene su velocidad máxima.</p>
 *
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class Accelerating extends Particle {
    
    private static final int MAX_SPEED = 10;

    /**
     * Constructor de AcceleratingParticle.
     *
     * @param color  Color de la partícula.
     * @param isRed  Define si la partícula es roja o azul.
     * @param px     Posición X inicial.
     * @param py     Posición Y inicial.
     * @param vx     Velocidad en X inicial.
     * @param vy     Velocidad en Y inicial.
     * @param board  Referencia al tablero.
     */
    public Accelerating(String color, boolean isRed, int px, int py, int vx, int vy, Create board) {
        super(color, isRed, px, py, vx, vy, board);
    }

    /**
     * Mueve la partícula y aumenta su velocidad si colisiona con una pared, el piso o el techo.
     */
    @Override
    protected void moveParticle(Particle particle, Create board) {
        int newX = particle.getX() + particle.getVx();
        int newY = particle.getY() + particle.getVy();
        int newVx = particle.getVx();
        int newVy = particle.getVy();
        
        int divisionX = board.getDivisionX();
        int leftLimit = board.getLeftChamberMinX();
        int rightLimit = board.getRightChamberMaxX();
        
        boolean wasLeftChamber = particle.getX() < divisionX;
        boolean isLeftChamber = newX < divisionX;
        
        boolean crossingDivision = (wasLeftChamber && !isLeftChamber) || (!wasLeftChamber && isLeftChamber);
        
        boolean collided = false;
                
        if (crossingDivision) {
            boolean passed = Demon.handleDemonCollision(particle, board);
            if (!passed) {
                // Rebote si el demonio no permite el paso
                newVx = -newVx;
                newX = particle.getX() + newVx;
                collided = true;
            }
        }

        // Colisión con paredes laterales
        if (isLeftChamber) {
            if (newX <= leftLimit) {
                newVx = -newVx;
                newX = leftLimit;
                collided = true;
            }
        } else {
            if (newX >= rightLimit) {
                newVx = -newVx;
                newX = rightLimit;
                collided = true;
            }
        }

        // Colisión con techo o piso
        if (newY <= board.getTopLimit() || newY >= board.getBottomLimit()) {
            newVy = -newVy;
            newY = Math.max(board.getTopLimit(), Math.min(newY, board.getBottomLimit()));
            collided = true;
        }

        // Aumentar velocidad si hubo colisión
        if (collided) {
            if (Math.abs(newVx) < MAX_SPEED) newVx += (newVx > 0) ? 1 : -1;
            if (Math.abs(newVy) < MAX_SPEED) newVy += (newVy > 0) ? 1 : -1;
        }

        particle.move(board, newVx, newVy);
    }
}