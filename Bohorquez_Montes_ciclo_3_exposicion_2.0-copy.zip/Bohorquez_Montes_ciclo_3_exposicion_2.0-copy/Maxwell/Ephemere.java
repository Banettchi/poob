package Maxwell;

/**
 * Representa una partícula efímera que pierde velocidad con cada colisión.
 * 
 * <p>Si la velocidad llega a (0,0), la partícula se vuelve invisible.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.4
 */
public class Ephemere extends Particle {

    /**
     * Constructor de EphemereParticle.
     * 
     * @param color  Color de la partícula.
     * @param isRed  Define si la partícula es roja o azul.
     * @param px     Posición X inicial.
     * @param py     Posición Y inicial.
     * @param vx     Velocidad en X inicial.
     * @param vy     Velocidad en Y inicial.
     * @param board  Referencia al tablero.
     */
    public Ephemere(String color, boolean isRed, int px, int py, int vx, int vy, Create board) {
        super(color, isRed, px, py, vx, vy, board);
    }

    /**
     * Mueve la partícula y reduce su velocidad si colisiona con una pared, el piso o el techo.
     */
    @Override
    protected void moveParticle(Particle particle, Create board) {
        int newX = particle.getX() + particle.getVx();
        int newY = particle.getY() + particle.getVy();
        int newVx = particle.getVx();
        int newVy = particle.getVy();

        int divisionX = board.getDivisionX();
        int leftLimit = board.getLeftChamberMinX();
        int rightLimit = board.getRightChamberMaxX();

        boolean wasLeftChamber = particle.getX() < divisionX;
        boolean isLeftChamber = newX < divisionX;

        boolean collided = false;
        
        boolean crossingDivision = (wasLeftChamber && !isLeftChamber) || (!wasLeftChamber && isLeftChamber);
        
        if (crossingDivision) {
            boolean passed = Demon.handleDemonCollision(particle, board);
            if (!passed) {
                // Rebote si el demonio no permite el paso
                newVx = -newVx;
                newX = particle.getX() + newVx;  // Corregir la posición para evitar que atraviese
            }
        }

        // Colisión con paredes laterales
        if (isLeftChamber) {
            if (newX <= leftLimit) {
                newVx = -newVx;
                collided = true;
                newX = leftLimit;
            }
        } else {
            if (newX >= rightLimit) {
                newVx = -newVx;
                collided = true;
                newX = rightLimit;
            }
        }

        // Colisión con techo o piso
        if (newY <= board.getTopLimit() || newY >= board.getBottomLimit()) {
            newVy = -newVy;
            collided = true;
            newY = Math.max(board.getTopLimit(), Math.min(newY, board.getBottomLimit()));
        }

        // Reducir velocidad si hubo colisión
        if (collided) {
            if (newVx > 0) newVx--;
            else if (newVx < 0) newVx++;

            if (newVy > 0) newVy--;
            else if (newVy < 0) newVy++;
        }

        // Hacer invisible si la velocidad es cero
        if (newVx == 0 && newVy == 0) {
            particle.makeInvisible();
        } else {
            particle.move(board, newVx, newVy);
        }
    }

}