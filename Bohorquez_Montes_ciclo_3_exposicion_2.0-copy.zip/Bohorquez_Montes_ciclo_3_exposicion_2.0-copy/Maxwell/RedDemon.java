package Maxwell;

/**
 * Clase que representa un demonio de Maxwell de tipo rojo.
 * 
 * <p>El {@code RedDemon} controla el paso de partículas a través de una puerta,
 * permitiendo únicamente aquellas que son de color rojo.</p>
 *
 * <p>Cambia su color visual a negro para distinguirse en la interfaz gráfica.</p>
 * 
 * <p>Hereda de {@link Demon}.</p>
 * 
 * @author Juan Carlos y Diego Montes
 * @version 1.0
 */
public class RedDemon extends Demon {

    /**
     * Constructor que crea un demonio rojo en una posición específica del tablero.
     *
     * @param px Posición X del demonio.
     * @param py Posición Y del demonio.
     */
    public RedDemon(int px, int py) {
        super(px, py);
        shape.changeColor("black"); // Se representa con color negro
    }

    /**
     * Determina si una partícula puede pasar a través del demonio.
     *
     * <p>Solo se permite el paso si la partícula es roja.</p>
     *
     * @param particle La partícula que intenta pasar.
     * @return {@code true} si la partícula es roja; {@code false} en caso contrario.
     */
    @Override
    public boolean canPass(Particle particle) {
        return particle.isRed();
    }
}
