package Maxwell;

import java.util.List;

/**
 * Clase que controla la visibilidad del simulador de Maxwell.
 * 
 * <p>Permite mostrar u ocultar todos los elementos del simulador, incluyendo el tablero,
 * los demonios, las partículas y los agujeros negros. También puede gestionar el inicio
 * y la detención del movimiento de las partículas.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class Visible {
    private final Create board;
    private boolean isVisible;  // Indica si el simulador está visible
    private boolean isMoving;   // Indica si las partículas están en movimiento

    /**
     * Constructor de la clase Visible.
     * 
     * <p>Inicializa el control de visibilidad y movimiento del simulador.</p>
     * 
     * @param board Tablero principal del simulador.
     */
    public Visible(Create board) {
        this.board = board;
        this.isVisible = true;  // Se inicia visible por defecto
        this.isMoving = false;  // El movimiento comienza detenido
    }

    /**
     * Hace visible todo el simulador (tablero, demonios, partículas y agujeros).
     * 
     * <p>Activa la visibilidad de todos los elementos gráficos del simulador.</p>
     */
    public void makeVisible() {
        board.makeVisible();

        for (Demon demon : Demon.getDemons()) {
            demon.makeVisible();
        }
        for (Particle particle : Particle.getParticles()) {
            particle.makeVisible();
        }
        for (Hole hole : Hole.getHoles()) {
            hole.makeVisible();
        }

        isVisible = true;
    }

    /**
     * Hace invisible todo el simulador (tablero, demonios, partículas y agujeros).
     * 
     * <p>Desactiva la visibilidad de todos los elementos gráficos del simulador.
     * Si las partículas estaban en movimiento, se mantiene su ejecución.</p>
     */
    public void makeInvisible() {
        board.makeInvisible();

        for (Demon demon : Demon.getDemons()) {
            demon.makeInvisible();
        }
        for (Particle particle : Particle.getParticles()) {
            particle.makeInvisible();
        }
        for (Hole hole : Hole.getHoles()) {
            hole.makeInvisible();
        }

        isVisible = false;
    }

    /**
     * Alterna entre visible e invisible el simulador.
     * 
     * <p>Si el simulador está visible, lo oculta. Si está oculto, lo muestra.</p>
     */
    public void toggleVisibility() {
        if (isVisible) {
            makeInvisible();
        } else {
            makeVisible();
        }
    }

    /**
     * Verifica si el simulador está visible o no.
     * 
     * @return true si el simulador está visible, false si está oculto.
     */
    public boolean isVisible() {
        return isVisible;
    }
    
     /**
     * Verifica si las partículas están en movimiento.
     * 
     * @return true si las partículas están en movimiento, false en caso contrario.
     */
    public boolean isMoving() {
        return isMoving;
    }
}