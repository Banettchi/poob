package Maxwell;

/**
 * Representa una partícula voladora en el simulador de Maxwell.
 * 
 * <p>
 * A diferencia de las partículas normales, las partículas voladoras no pueden ser
 * absorbidas por agujeros negros. Ignoran completamente estas colisiones.
 * </p>
 * 
 * <p>
 * Esta clase extiende a {@link Particle} y redefine el comportamiento del movimiento
 * para evitar la interacción con los agujeros.
 * </p>
 * 
 * @author Juan Carlos Bohorquez
 * @author Diego Montes
 * @version 1.0
 */

public class Flying extends Particle {
    /**
     * Constructor de la partícula voladora.
     *
     * @param color Color de la partícula.
     * @param isRed true si la partícula es roja, false si es azul.
     * @param px Posición en X.
     * @param py Posición en Y.
     * @param vx Velocidad en X.
     * @param vy Velocidad en Y.
     * @param board Tablero donde se encuentra la partícula.
     */
    public Flying(String color, boolean isRed, int px, int py, int vx, int vy, Create board) {
        super(color, isRed, px, py, vx, vy, board);
        this.canBeAbsorbed = false; // Las partículas voladoras no son absorbidas
    }

    /**
     * Sobreescribe el movimiento para que no sea absorbida por los agujeros.
     */
    @Override
    public void move(Create board, int newVx, int newVy) {
        erase();
        this.vx = newVx;
        this.vy = newVy;
        this.px += vx;
        this.py += vy;

        // Movemos en el canvas
        shape.moveHorizontal(vx);
        shape.moveVertical(vy);
        
        draw();
    }

    /**
     * Sobreescribe el método para que ignore los agujeros.
     */
    public static void updateMovement(Create board) {
        if (ticks <= 0) return;

        // Mueve cada partícula sin verificar colisiones con agujeros
        for (Particle particle : Particle.getParticles()) {
            if (!particle.isAbsorbed()) {
                particle.moveParticle(particle, board);
            }
        }

        // Remueve solo las partículas absorbidas por otras causas
        Particle.getParticles().removeIf(Particle::isAbsorbed);
    }
}
