package Maxwell;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Clase principal que administra el simulador de Maxwell.
 * 
 * <p>Gestiona la creación del tablero, la visibilidad de los elementos,
 * la consulta de información, el movimiento de las partículas,
 * y la interacción con demonios y agujeros negros.</p>
 * 
 * <p>Permite crear partículas de diferentes tipos, así como demonios y
 * agujeros normales o especiales, controlando el estado y visualización del simulador.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.5
 */
public class MaxwellContainer {
    private final Create board;    
    private final Visible visibility; 
    private final Consult consult;
    private static final Random random = new Random(); 
    private final List<MovingHole> movingHoles;
    private int width;
    private int height;
    private int demonY;
    private int blueParticles;
    private int redParticles;
    private int[][] particles;
    
    /**
     * Constructor que permite crear un contenedor con configuraciones iniciales personalizadas.
     * 
     * @param width     Ancho del tablero.
     * @param height    Alto del tablero.
     * @param d         Posición en Y del demonio.
     * @param b         Número de partículas azules.
     * @param r         Número de partículas rojas.
     * @param particles Arreglo con las partículas predefinidas.
     */
    public MaxwellContainer(int width, int height, int d, int b, int r, int[][] particles) {
        this.width = width;
        this.height = height;
        this.demonY = d;
        this.blueParticles = b;
        this.redParticles = r;
        this.particles = particles;
        
        this.board = new Create(width, height); // 🔹 Se inicializa board
        this.visibility = new Visible(board);
        this.consult = new Consult(board);
        this.movingHoles = new ArrayList<>();
    }
    

    /**
     * Constructor de {@code MaxwellContainer} que inicializa el tablero y los controladores.
     * 
     * @param width  Ancho del tablero.
     * @param height Alto del tablero.
     */
    public MaxwellContainer(int width, int height) { 
        this.board = new Create(width, height);
        this.visibility = new Visible(board);
        this.consult = new Consult(board);
        this.movingHoles = new ArrayList<>();
    }
    

    /**
     * Agrega un demonio en la división roja, centrado en el eje X.
     * 
     * @param positionY Posición en Y donde se ubicará el demonio.
     */
    public void addDemon(int positionY) {
        int divisionCenterX = board.getDivisionX() + board.getDivisionWidth() / 2;
        Demon demon = new Demon(divisionCenterX, positionY);
        demon.makeVisible();
        Demon.demons.add(demon);
    }

    /**
     * Agrega un demonio de un tipo específico: "normal", "blue", "red" o "weak".
     * 
     * @param type      Tipo del demonio.
     * @param positionY Posición vertical del demonio.
     */
    public void addDemon(String type, int positionY) {
        int divisionCenterX = board.getDivisionX() + board.getDivisionWidth() / 2;
    
        if (type.equalsIgnoreCase("blue")) {
            BlueDemon demon = new BlueDemon(divisionCenterX, positionY);
            demon.makeVisible();
            return;
        }
    
        if (type.equalsIgnoreCase("weak")) {
            WeakDemon demon = new WeakDemon(divisionCenterX, positionY);
            demon.makeVisible();
            return;
        }
    
        if (type.equalsIgnoreCase("normal")) {
            addDemon(positionY);
            return;
        }
        
        if (type.equalsIgnoreCase("red")) {
            RedDemon demon = new RedDemon(divisionCenterX, positionY);
            demon.makeVisible();
            return;
        }
    }
    
    /**
     * Elimina el número indicado de demonios del tablero, del más reciente al más antiguo.
     * 
     * @param count Número de demonios a eliminar.
     */
    public void delDemon(int count) {
        if (!Demon.demons.isEmpty()) {
            Demon demon = Demon.demons.remove(Demon.demons.size() - 1);
            demon.makeInvisible();
        }
        
        for (int i = 0; i < count && !Demon.demons.isEmpty(); i++) {
            Demon demon = Demon.demons.remove(Demon.demons.size() - 1);
            demon.makeInvisible();
        }
    }

    /**
     * Agrega una partícula con parámetros personalizados o aleatorios.
     * 
     * @param color  Color de la partícula. Si es null, se elige aleatorio.
     * @param isRed  Define si la partícula es roja o azul.
     * @param px     Posición X. Si es -1, se genera aleatoriamente.
     * @param py     Posición Y. Si es -1, se genera aleatoriamente.
     * @param vx     Velocidad en X. Si es 0, se genera aleatoriamente.
     * @param vy     Velocidad en Y. Si es 0, se genera aleatoriamente.
     */
    public void addParticle(String color, boolean isRed, int px, int py, int vx, int vy) {
        if (Particle.particles.size() < Particle.maxParticles) {
            if (color == null) {
                color = Particle.colors[random.nextInt(Particle.colors.length)];
            }
    
            if (px == -1 || py == -1) {
                int leftMinX = board.getLeftChamberMinX();
                int rightMaxX = board.getRightChamberMaxX();
                int divisionX = board.getDivisionX();
                int divisionWidth = board.getDivisionWidth();
    
                do {
                    px = random.nextInt(rightMaxX - leftMinX) + leftMinX;
                } while (px >= (divisionX - divisionWidth / 2) && px <= (divisionX + divisionWidth / 2));
    
                py = random.nextInt(board.getChamberMaxY() - board.getChamberMinY()) + board.getChamberMinY();
            }
    
            if (vx == 0) {
                vx = random.nextInt(Particle.speed * 2 + 1) - Particle.speed;
            }
            if (vy == 0) {
                vy = random.nextInt(Particle.speed * 2 + 1) - Particle.speed;
            }
    
            Particle particle = new Particle(color, isRed, px, py, vx, vy, board);
            particle.makeVisible();
            Particle.particles.add(particle);
        }
    }

    /**
     * Agrega una partícula de tipo específico con parámetros personalizados o aleatorios.
     * 
     * @param color  Color de la partícula. Si es null, se elige aleatorio.
     * @param isRed  Define si la partícula es roja o azul.
     * @param px     Posición X. Si es -1, se genera aleatoriamente.
     * @param py     Posición Y. Si es -1, se genera aleatoriamente.
     * @param vx     Velocidad en X. Si es 0, se genera aleatoriamente.
     * @param vy     Velocidad en Y. Si es 0, se genera aleatoriamente.
     * @param type   Tipo de partícula a crear ("normal", "ephemere", "flying","rotator","accelerating".).
     */

    public void addParticle(String type, String color, boolean isRed, int px, int py, int vx, int vy) {
        if (Particle.particles.size() < Particle.maxParticles) {
            if (color == null) {
                color = Particle.colors[random.nextInt(Particle.colors.length)];
            }
    
            if (px == -1 || py == -1) {
                int leftMinX = board.getLeftChamberMinX();
                int rightMaxX = board.getRightChamberMaxX();
                int divisionX = board.getDivisionX();
                int divisionWidth = board.getDivisionWidth();
    
                do {
                    px = random.nextInt(rightMaxX - leftMinX) + leftMinX;
                } while (px >= (divisionX - divisionWidth / 2) && px <= (divisionX + divisionWidth / 2));
    
                py = random.nextInt(board.getChamberMaxY() - board.getChamberMinY()) + board.getChamberMinY();
            }
    
            if (vx == 0) {
                vx = random.nextInt(Particle.speed * 2 + 1) - Particle.speed;
            }
    
            if (vy == 0) {
                vy = random.nextInt(Particle.speed * 2 + 1) - Particle.speed;
            }
    
            if (type.equalsIgnoreCase("flying")) {
                Flying flyingParticle = new Flying(color, isRed, px, py, vx, vy, board);
                flyingParticle.makeVisible();
                Particle.particles.add(flyingParticle);
            }
    
            if (type.equalsIgnoreCase("normal")) {
                Particle particle = new Particle(color, isRed, px, py, vx, vy, board);
                particle.makeVisible();
                Particle.particles.add(particle);
            }
        
            if (type.equalsIgnoreCase("ephemere")) {
                Ephemere particle = new Ephemere(color, isRed, px, py, vx, vy, board);
                particle.makeVisible();
                Particle.particles.add(particle);
                return;
            }
            
            if(type.equalsIgnoreCase("rotator")){
                Rotator particle = new Rotator(color, isRed, px, py, vx, vy, board);
                particle.makeVisible();
                Particle.particles.add(particle);
                return;
            }
            
            if(type.equalsIgnoreCase("accelerating")){
                Accelerating particle = new Accelerating(color, isRed, px, py, vx, vy, board);
                particle.makeVisible();
                Particle.particles.add(particle);
                return;
            }
        }
    }
    
    /**
     * Elimina la última partícula agregada.
     */
    public void delParticle() {
        if (!Particle.particles.isEmpty()) {
            Particle particle = Particle.particles.remove(Particle.particles.size() - 1);
            particle.makeInvisible();
        }
    }

    /**
     * Agrega un agujero negro con tamaño y posición específicos o aleatorios 
     * en una posición dentro de las cámaras.
     * 
     * @param px   Posición X del agujero. Si es -1, se genera aleatoriamente.
     * @param py   Posición Y del agujero. Si es -1, se genera aleatoriamente.
     * @param size Tamaño del agujero. Si es 0, se elige aleatoriamente entre 15 y 30.
     */
    public void addHole(int px, int py, int size) {
        Random rand = new Random();
        int divisionX = board.getDivisionX();
        int divisionWidth = board.getDivisionWidth();
        int chamberMinY = board.getChamberMinY();
        int chamberMaxY = board.getChamberMaxY();
        
        boolean isLeftSide = rand.nextBoolean();
        
        if (px == -1 || py == -1) {
            px = random.nextInt(board.getRightChamberMaxX() - board.getLeftChamberMinX()) + board.getLeftChamberMinX();
            py = random.nextInt(board.getChamberMaxY() - board.getChamberMinY()) + board.getChamberMinY();
        }

        if (px == -1) {
            px = isLeftSide 
                 ? board.getLeftChamberMinX() + 20 
                 : board.getRightChamberMinX() + 20;
        }

        if (py == -1) {
            py = rand.nextInt(chamberMaxY - chamberMinY) + chamberMinY;
        }

        if (size == 0) {
            size = rand.nextInt(16) + 15; // 🔹 Tamaño entre 15 y 30
        }

        Hole hole = new Hole(px, py, size);
        hole.makeVisible();
    }
    
    /**
     * Agrega un agujero negro que puede ser normal o en movimiento.
     * 
     * @param type Tipo de agujero: "normal" o "movil". Si no es válido, no hace nada
     * @param px   Posición X del agujero.
     * @param py   Posición Y del agujero.
     * @param size Tamaño del agujero.
     */
    public void addHole(String type, int px, int py, int size) {
        if (type.equalsIgnoreCase("movil")) {
            Random rand = new Random();
        
            if (px == -1) {
                px = rand.nextInt(board.getRightChamberMaxX() - board.getLeftChamberMinX()) + board.getLeftChamberMinX();
            }
            if (py == -1) {
                py = rand.nextInt(board.getChamberMaxY() - board.getChamberMinY()) + board.getChamberMinY();
            }
            if (size == 0) {
                size = rand.nextInt(16) + 15;
            }
        
            MovingHole hole = new MovingHole(board, px, py, 1, 1, size);
            hole.makeVisible();
            movingHoles.add(hole);
        }
        
        if (type.equalsIgnoreCase("normal")) {
            addHole(px, py, size);
            return;
        }
    }

    /**
     * Elimina el último agujero negro agregado.
     */
    public void delHole() {
        if (!Hole.holes.isEmpty()) {
            Hole hole = Hole.holes.remove(Hole.holes.size() - 1);
            hole.makeInvisible();
            
            if (!movingHoles.isEmpty() && movingHoles.get(movingHoles.size() - 1) == hole) {
                movingHoles.remove(movingHoles.size() - 1);
            }
        }
    }

    /**
     * Obtiene la referencia al tablero del contenedor.
     * @return Objeto Board.
     */
    public Create getBoard() {
        return board;
    }
    
    /**
     * Hace visible todo el simulador (tablero, demonios, partículas y agujeros negros).
     */
    public void makeVisible() {
        visibility.makeVisible();
    }

    /**
     * Oculta todo el simulador (tablero, demonios, partículas y agujeros negros).
     */
    public void makeInvisible() {
        visibility.makeInvisible();
    }

    /**
     * Inicia el movimiento de las partículas con un número de ciclos personalizado.
     * 
     * @param tickCount Número de ciclos antes de detenerse.
     */
    public void start(int tickCount) {
        MovingHole.startMoving(tickCount); 
        Particle.startMoving(board, tickCount);  // 🔹 Asegurar que las partículas también comiencen
    
        while (tickCount > 0) { 
            for (MovingHole hole : movingHoles) {
                hole.move(board); 
            }
            Particle.updateMovement(board); 
            tickCount--; 
        }
    
        Particle.stopMoving();
        MovingHole.stopMoving(); // 🔹 Detener los *holes* cuando se acaben los *ticks*
    }

    /**
     * Finaliza el simulador (detiene el movimiento y oculta los elementos).
     */
    public void finish() {
        for (Particle particle : Particle.getParticles()) {
            particle.stopMoving();
        }
        makeInvisible();
    }


    /**
     * Verifica que el simulador esté funcionando correctamente.
     * 
     * @return {@code true} si no hay errores, {@code false} si algo está mal.
     */
    public boolean ok() {
        return board != null && visibility != null;
    }

    /**
     * Muestra toda la información del simulador.
     * 
     * <p>Combina las consultas sobre el tablero, los demonios, las partículas y los agujeros negros.</p>
     */
    public void showFullInfo() {
        consult.showBoardInfo();
        consult.showDemonsInfo();
        consult.showParticlesInfo();
        consult.showHolesInfo();
    }
    
    /**
     * Verifica si se ha alcanzado el estado objetivo:
     * todas las partículas azules están en la cámara izquierda,
     * y todas las partículas rojas están en la cámara derecha.
     *
     * @return true si se cumple la condición, false en caso contrario.
     */
    public boolean isGoal() {
        int divisionX = board.getDivisionX();
    
        for (Particle p : Particle.particles) {
            if (p.isRed() && p.getX() > divisionX) {
                // Partícula roja en el lado izquierdo (incorrecto)
                return false;
            }
            if (!p.isRed() && p.getX() < divisionX) {
                // Partícula azul en el lado derecho (incorrecto)
                return false;
            }
        }
    
        return true; // Todas las partículas están en su lugar correcto
    }
    
    /**
     * Devuelve la lista de demonios actuales en el tablero.
     * 
     * @return Lista de demonios.
     */
    public List<Demon> getDemons() {
        return Demon.getDemons();
    }

    /**
     * Devuelve la lista de partículas activas.
     * 
     * @return Lista de partículas.
     */
    public List<Particle> getParticles() {
        return Particle.particles;
    }

    /**
     * Devuelve la lista de agujeros negros activos.
     * 
     * @return Lista de agujeros negros.
     */
    public List<Hole> getHoles() {
        return Hole.getHoles();
    }
}