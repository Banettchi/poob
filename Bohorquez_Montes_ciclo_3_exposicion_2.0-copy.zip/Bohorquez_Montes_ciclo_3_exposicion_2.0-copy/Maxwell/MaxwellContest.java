package Maxwell;

import java.util.Scanner;

/**
 * Clase principal que resuelve el problema de Maxwell's Demon.
 * 
 * <p>Determina el tiempo mínimo en que todas las partículas colisionan con el demonio
 * y simula la animación del proceso.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class MaxwellContest {

    // Umbral de precisión para cálculos de colisión
    private static final double precisionThreshold = 1e-9;

    // Número máximo de iteraciones para detectar colisiones
    private static final int maxIterations = 1000;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leer dimensiones del contenedor y la posición del demonio
        int width = scanner.nextInt();
        int height = scanner.nextInt();
        int demonY = scanner.nextInt();
        int redParticles = scanner.nextInt();
        int blueParticles = scanner.nextInt();
        int totalParticles = redParticles + blueParticles;

        // Leer datos de todas las partículas
        int[][] particles = new int[totalParticles][4];
        for (int i = 0; i < totalParticles; i++) {
            for (int j = 0; j < 4; j++) {
                particles[i][j] = scanner.nextInt();
            }
        }

        // Resolver el problema
        double result = findMinimumTime(width, height, demonY, particles);
        System.out.println(result == -1 ? "impossible" : result);

        // Simular la animación
        simulate(width, height, demonY, particles);

        scanner.close();
    }

    /**
     * Calcula el tiempo mínimo necesario para que todas las partículas colisionen con el demonio.
     * 
     * @param width     Ancho del contenedor.
     * @param height    Altura del contenedor.
     * @param demonY    Posición en Y del demonio.
     * @param particles Arreglo con los datos de las partículas.
     * @return Tiempo mínimo en que todas las partículas colisionan con el demonio, o -1 si es imposible.
     */
    private static double findMinimumTime(int width, int height, int demonY, int[][] particles) {
        double maxTime = 0;

        for (int[] particle : particles) {
            int posX = particle[0], posY = particle[1];
            int velX = particle[2], velY = particle[3];

            double time = calculateCollisionTime(posX, posY, velX, velY, width, height, demonY);
            if (time == -1) return -1;
            maxTime = Math.max(maxTime, time);
        }
        return maxTime;
    }

    /**
     * Calcula el tiempo en que una partícula colisiona con el demonio.
     * 
     * @param posX   Posición inicial en X de la partícula.
     * @param posY   Posición inicial en Y de la partícula.
     * @param velX   Velocidad en X de la partícula.
     * @param velY   Velocidad en Y de la partícula.
     * @param width  Ancho del contenedor.
     * @param height Altura del contenedor.
     * @param demonY Posición en Y del demonio.
     * @return Tiempo en que la partícula colisiona con el demonio, o -1 si nunca lo hace.
     */
    private static double calculateCollisionTime(int posX, int posY, int velX, int velY, int width, int height, int demonY) {
        double bestTime = -1;
        int direction = (velX > 0) ? 1 : -1;
        int startBounce = (int) Math.ceil(posX / (2.0 * width)) * direction;

        for (int bounce = startBounce; Math.abs(bounce - startBounce) < maxIterations; bounce += direction) {
            double time = (2 * width * bounce - posX) / (double) velX;
            if (time < precisionThreshold) continue;

            if (Math.abs(velY) < precisionThreshold) {
                if (Math.abs(posY - demonY) < precisionThreshold) {
                    return time;
                } else {
                    continue;
                }
            }

            double yRaw = posY + velY * time;
            double yMod = ((yRaw % (2 * height)) + 2 * height) % (2 * height);
            double yFinal = (yMod <= height) ? yMod : (2 * height - yMod);

            if (Math.abs(yFinal - demonY) < precisionThreshold) {
                return time;
            }
        }
        return bestTime;
    }

    /**
     * Simula la animación utilizando MaxwellContainer.
     * 
     * @param width     Ancho del contenedor.
     * @param height    Altura del contenedor.
     * @param demonY    Posición en Y del demonio.
     * @param particles Arreglo con los datos de las partículas.
     */
    private static void simulate(int width, int height, int demonY, int[][] particles) {
        int scale = 100; 

        // Crear el simulador con dimensiones escaladas
        MaxwellContainer simulator = new MaxwellContainer(width * scale, height * scale);
        simulator.makeVisible();

        // Calcular la posición central del demonio
        int demonYScaled = (height * scale) / 2;
        simulator.addDemon(demonYScaled);

        // Agregar partículas al simulador con los ajustes de color y posición
        for (int[] particle : particles) {
            int posX = particle[0];
            int posY = particle[1];
            int velX = particle[2]; 
            int velY = particle[3];

            // Determinar color de la partícula
            boolean isRed = posX < 0;
            String color = isRed ? "red" : "blue";

            // Ajustar posiciones negativas o positivas
            posX = (posX < 0) ? Math.abs(posX) * -scale : posX * scale;
            posY = (posY < 0) ? Math.abs(posY) * -scale : posY * scale;

            simulator.addParticle(color, isRed, posX, posY, velX, velY);
        }

        // Iniciar la simulación con 100 ticks
        simulator.start(100);
    }
}
