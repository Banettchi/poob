package Maxwell;

/**
 * Clase que representa un demonio de Maxwell de tipo azul.
 * 
 * <p>El {@code BlueDemon} regula el paso de partículas en el tablero, 
 * permitiendo únicamente aquellas que **no** son de color rojo.</p>
 *
 * <p>Visualmente se representa con el color cian.</p>
 *
 * <p>Hereda de {@link Demon}.</p>
 * 
 * @author Juan Carlos y Diego Montes
 * @version 1.0
 */
public class BlueDemon extends Demon {

    /**
     * Constructor que crea un demonio azul en una posición específica del tablero.
     *
     * @param px Posición X del demonio.
     * @param py Posición Y del demonio.
     */
    public BlueDemon(int px, int py) {
        super(px, py);
        shape.changeColor("cyan"); // Se representa con color cian
    }

    /**
     * Determina si una partícula puede pasar a través del demonio.
     *
     * <p>Solo se permite el paso si la partícula **no** es roja.</p>
     *
     * @param particle La partícula que intenta pasar.
     * @return {@code true} si la partícula no es roja; {@code false} en caso contrario.
     */
    @Override
    public boolean canPass(Particle particle) {
        return !particle.isRed();
    }
}
