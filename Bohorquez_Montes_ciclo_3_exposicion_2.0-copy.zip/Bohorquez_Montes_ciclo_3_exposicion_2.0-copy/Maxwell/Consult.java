package Maxwell;

import java.util.List;

/**
 * Clase para consultar información sobre el tablero y sus elementos en el simulador de Maxwell.
 * 
 * <p>Permite obtener información detallada sobre el tablero, los demonios,
 * las partículas y los agujeros negros presentes en el simulador.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.1
 */
public class Consult {
    private final Create board;  // Referencia al tablero del simulador

    /**
     * Constructor de la clase Consult.
     * 
     * <p>Inicializa la consulta con una referencia al tablero.</p>
     * 
     * @param board Referencia a la clase Create para obtener datos del simulador.
     */
    public Consult(Create board) {
        this.board = board;
    }

    /**
     * Muestra información general del tablero.
     * 
     * <p>Incluye detalles sobre dimensiones, división y cámaras del tablero.</p>
     */
    public void showBoardInfo() {
        System.out.println("=== BOARD INFORMATION ===");
        System.out.println(board.getBoardInfo());
        System.out.println("=========================");
    }

    /**
     * Muestra información sobre los demonios en el tablero.
     * 
     * <p>Imprime el número total de demonios y sus coordenadas.</p>
     */
    public void showDemonsInfo() {
        System.out.println("=== DEMONS INFORMATION ===");
        List<Demon> demons = Demon.getDemons();
        System.out.println("Total demons: " + demons.size());

        for (int i = 0; i < demons.size(); i++) {
            System.out.println("Demon " + (i + 1) + " - X: " + demons.get(i).getX() + ", Y: " + demons.get(i).getY());
        }
        System.out.println("=========================");
    }

    /**
     * Muestra información sobre las partículas en el tablero.
     * 
     * <p>Imprime el número total de partículas y sus coordenadas.</p>
     */
    public void showParticlesInfo() {
        System.out.println("=== PARTICLES INFORMATION ===");
        List<Particle> particles = Particle.getParticles();
        System.out.println("Total particles: " + particles.size());

        for (int i = 0; i < particles.size(); i++) {
            System.out.println("Particle " + (i + 1) + " - X: " + particles.get(i).getX() + ", Y: " + particles.get(i).getY());
        }
        System.out.println("===========================");
    }

    /**
     * Muestra información sobre los agujeros negros en el tablero y las partículas absorbidas.
     * 
     * <p>Imprime el número total de agujeros, sus coordenadas y las partículas que han absorbido.</p>
     */
    public void showHolesInfo() {
        System.out.println("=== BLACK HOLES INFORMATION ===");
        List<Hole> holes = Hole.getHoles();
        System.out.println("Total holes: " + holes.size());

        for (int i = 0; i < holes.size(); i++) {
            Hole hole = holes.get(i);
            System.out.println("Hole " + (i + 1) + " - X: " + hole.getX() + ", Y: " + hole.getY());

            List<Particle> absorbedParticles = hole.getAbsorbedParticles();
            System.out.println("  Absorbed Particles: " + absorbedParticles.size());

            for (int j = 0; j < absorbedParticles.size(); j++) {
                Particle particle = absorbedParticles.get(j);
                System.out.println("    - Particle " + (j + 1) + " | X: " + particle.getX() + ", Y: " + particle.getY() );
            }
        }
        System.out.println("==============================");
    }
}
