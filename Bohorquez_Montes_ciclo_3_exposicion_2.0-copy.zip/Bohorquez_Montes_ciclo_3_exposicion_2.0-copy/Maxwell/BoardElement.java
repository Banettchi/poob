package Maxwell;


/**
 * Clase abstracta que representa un elemento en el tablero del simulador de Maxwell.
 * 
 * <p>Define la estructura base para elementos gráficos en el simulador. 
 * Proporciona métodos para gestionar la visibilidad y el movimiento, 
 * mientras que sus subclases deben implementar la representación visual.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public abstract class BoardElement {
    // Posición en el eje X
    protected int px;

    // Posición en el eje Y
    protected int py;

    // Indica si el elemento es visible en el tablero
    protected boolean isVisible;

    /**
     * Constructor de la clase BoardElement.
     * 
     * @param px Posición inicial en X.
     * @param py Posición inicial en Y.
     */
    public BoardElement(int px, int py) {
        this.px = px;
        this.py = py;
        this.isVisible = false;
    }

    /**
     * Hace visible el elemento en el tablero.
     */
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible el elemento en el tablero.
     */
    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    /**
     * Mueve el elemento en el tablero.
     * 
     * @param dx Desplazamiento en X.
     * @param dy Desplazamiento en Y.
     */
    public void move(int dx, int dy) {
        erase();
        px += dx;
        py += dy;
        draw();
    }

    /**
     * Retorna la posición en X.
     * 
     * @return Coordenada X del elemento.
     */
    public int getX() {
        return px;
    }

    /**
     * Retorna la posición en Y.
     * 
     * @return Coordenada Y del elemento.
     */
    public int getY() {
        return py;
    }

    // Método abstracto que dibuja el elemento (debe ser implementado en subclases)
    protected abstract void draw();

    // Método abstracto que borra la representación visual del elemento
    protected abstract void erase();
}
