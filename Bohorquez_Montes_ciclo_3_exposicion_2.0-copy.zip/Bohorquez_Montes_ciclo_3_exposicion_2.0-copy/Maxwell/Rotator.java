package Maxwell;

/**
 * Representa una partícula efímera que intercambia sus velocidades en cada colisión.
 *
 * <p>Si la velocidad llega a (0,0), la partícula se vuelve invisible.</p>
 *
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public class Rotator extends Particle {



    /**
     * Constructor de SwappingParticle.
     *
     * @param color  Color de la partícula.
     * @param isRed  Define si la partícula es roja o azul.
     * @param px     Posición X inicial.
     * @param py     Posición Y inicial.
     * @param vx     Velocidad en X inicial.
     * @param vy     Velocidad en Y inicial.
     * @param board  Referencia al tablero.
     */
    public Rotator(String color, boolean isRed, int px, int py, int vx, int vy, Create board) {
        super(color, isRed, px, py, vx, vy, board);
    }

    /**
     * Mueve la partícula e intercambia sus velocidades si colisiona con una pared, techo o piso.
     */
    @Override
    protected void moveParticle(Particle particle, Create board) {
        int newX = particle.getX() + particle.getVx();
        int newY = particle.getY() + particle.getVy();
        int newVx = particle.getVx();
        int newVy = particle.getVy();

        int divisionX = board.getDivisionX();
        int leftLimit = board.getLeftChamberMinX();
        int rightLimit = board.getRightChamberMaxX();

        boolean wasLeftChamber = particle.getX() < divisionX;
        boolean isLeftChamber = newX < divisionX;

        boolean collided = false;

        boolean crossingDivision = (wasLeftChamber && !isLeftChamber) || (!wasLeftChamber && isLeftChamber);
        if (crossingDivision) {
            boolean passed = Demon.handleDemonCollision(particle, board);
            if (!passed) {
                newVx = -newVx;
                collided = true;
                newX = particle.getX() + newVx;
            }
        }

        if (isLeftChamber && newX <= leftLimit) {
            newVx = -newVx;
            collided = true;
            newX = leftLimit;
        } else if (!isLeftChamber && newX >= rightLimit) {
            newVx = -newVx;
            collided = true;
            newX = rightLimit;
        }

        if (newY <= board.getTopLimit() || newY >= board.getBottomLimit()) {
            newVy = -newVy;
            collided = true;
            newY = Math.max(board.getTopLimit(), Math.min(newY, board.getBottomLimit()));
        }

        if (collided) {
            int temp = newVx;
            newVx = newVy;
            newVy = temp;
        }

        if (newVx == 0 && newVy == 0) {
            particle.makeInvisible();
        } else {
            particle.move(board, newVx, newVy);
        }
    }

}