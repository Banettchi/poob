package Maxwell;
import Shapes.Rectangle;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa el tablero del simulador de Maxwell.
 * 
 * <p>Esta clase crea la estructura del tablero, incluyendo las cámaras izquierda y derecha,
 * los bordes y la división central.</p>
 * 
 * @author Juan Carlos Bohorquez, Diego Montes
 * @version 1.0
 */
public final class Create {
    private final int width;
    private final int height;
    private final int centerX;
    private final int centerY;
    private Rectangle leftSide;
    private Rectangle rightSide;
    private Rectangle leftBorder;
    private Rectangle rightBorder;
    private Rectangle division;
    private final int divisionX;
    private final int divisionY;
    private final int divisionWidth;
    private final int divisionHeight;
    private final ArrayList<Demon> demons;
    private static final String chamberRed = "red";
    private static final String chamberBlue = "blue";
    private static final int margin = 10;
    private final ArrayList<Particle> particles;

    /**
     * Constructor de la clase Create. Inicializa el tablero con los valores especificados.
     * 
     * @param width  Ancho del tablero.
     * @param height Alto del tablero.
     */
    public Create(final int width, final int height) {
        this.width = width;
        this.height = height;
        this.centerX = width / 2;
        this.centerY = height / 2;
        this.demons = new ArrayList<>();
        this.particles = new ArrayList<>(); // Inicializa la lista de partículas
    
        this.divisionWidth = 6;
        this.divisionHeight = height - margin;
        this.divisionX = centerX - (divisionWidth / 2);
        this.divisionY = margin / 2;
    
        setupBoard();
    }

    /**
     * Configura el tablero, dibujando los elementos principales.
     */
    private void setupBoard() {
        drawBorders();
        drawSides();
        drawDivision();
    }

    /**
     * Dibuja los bordes exteriores del tablero.
     */
    private void drawBorders() {
        leftBorder = new Rectangle();
        leftBorder.changeSize(height, centerX);
        leftBorder.moveHorizontal(0);
        leftBorder.moveVertical(0);
        leftBorder.changeColor("black");
        leftBorder.makeVisible();

        rightBorder = new Rectangle();
        rightBorder.changeSize(height, centerX);
        rightBorder.moveHorizontal(centerX);
        rightBorder.moveVertical(0);
        rightBorder.changeColor("black");
        rightBorder.makeVisible();
    }

    /**
     * Dibuja las cámaras del tablero.
     */
    private void drawSides() {
        leftSide = new Rectangle();
        leftSide.changeSize(height - margin, centerX - margin);
        leftSide.moveHorizontal(margin / 2);
        leftSide.moveVertical(margin / 2);
        leftSide.changeColor("white");
        leftSide.makeVisible();

        rightSide = new Rectangle();
        rightSide.changeSize(height - margin, centerX - margin);
        rightSide.moveHorizontal(centerX + margin / 2);
        rightSide.moveVertical(margin / 2);
        rightSide.changeColor("white");
        rightSide.makeVisible();
    }

    /**
     * Dibuja la línea de división roja en el centro del tablero.
     */
    private void drawDivision() {
        division = new Rectangle();
        division.changeSize(divisionHeight, divisionWidth);
        division.moveHorizontal(divisionX);
        division.moveVertical(divisionY);
        division.changeColor("red");
        division.makeVisible();
    }
    
    /**
     * Obtiene la coordenada X del centro del tablero.
     * 
     * @return Centro en el eje X.
     */
    public int getCenterX() {
        return centerX;
    }

    /**
     * Obtiene la coordenada Y del centro del tablero.
     * 
     * @return Centro en el eje Y.
     */
    public int getCenterY() {
        return centerY;
    }
    
    /**
     * Obtiene la coordenada X mínima de la cámara izquierda.
     * 
     * @return Posición mínima en X de la cámara izquierda.
     */
    public int getLeftChamberMinX() {
        return margin;
    }

    /**
     * Obtiene la coordenada X máxima de la cámara izquierda.
     * 
     * @return Posición máxima en X de la cámara izquierda.
     */
    public int getLeftChamberMaxX() {
        return centerX - (margin + divisionWidth / 2);
    }

    /**
     * Obtiene la coordenada X mínima de la cámara derecha.
     * 
     * @return Posición mínima en X de la cámara derecha.
     */
    public int getRightChamberMinX() {
        return centerX + (margin + divisionWidth / 2);
    }

    /**
     * Obtiene la coordenada X máxima de la cámara derecha.
     * 
     * @return Posición máxima en X de la cámara derecha.
     */
    public int getRightChamberMaxX() {
        return width - margin;
    }

    /**
     * Obtiene la coordenada Y mínima de las cámaras.
     * 
     * @return Posición mínima en Y de las cámaras.
     */
    public int getChamberMinY() {
        return margin;
    }

    /**
     * Obtiene la coordenada Y máxima de las cámaras.
     * 
     * @return Posición máxima en Y de las cámaras.
     */
    public int getChamberMaxY() {
        return height - margin;
    }

    /**
     * Obtiene la coordenada X de la división roja.
     * 
     * @return Posición en X de la división.
     */
    public int getDivisionX() {
        return divisionX;
    }

    /**
     * Obtiene la coordenada Y de la división roja.
     * 
     * @return Posición en Y de la división.
     */
    public int getDivisionY() {
        return divisionY;
    }

    /**
     * Obtiene el ancho de la división roja.
     * 
     * @return Ancho de la división.
     */
    public int getDivisionWidth() {
        return divisionWidth;
    }
    
    /**
     * Obtiene la altura de la división roja.
     * 
     * @return Altura de la división.
     */
    public int getDivisionHeight() {
        return divisionHeight;
    }

    /**
     * Obtiene el ancho total del tablero.
     * 
     * @return Ancho del tablero.
     */
    public int getWidth() {
        return width;
    }

    /**
     * Obtiene la altura total del tablero.
     * 
     * @return Altura del tablero.
     */
    public int getHeight() {
        return height;
    }
    
    /**
     * Obtiene información general sobre el tablero.
     * 
     * @return Cadena con información del tablero.
     */
    public String getBoardInfo() {
        return "Board Information:\n" +
               "Width: " + width + ", Height: " + height + "\n" +
               "Center: (" + centerX + ", " + centerY + ")\n" +
               "Division: X = " + divisionX + ", Y = " + divisionY + "\n" +
               "Division Size: Width = " + divisionWidth + ", Height = " + divisionHeight + "\n" +
               "Chambers: Left = " + chamberRed + ", Right = " + chamberBlue;
    }
    
    /**
     * Hace visible el tablero y sus elementos.
     */
    public void makeVisible() {
        leftBorder.makeVisible();
        rightBorder.makeVisible();
        leftSide.makeVisible();
        rightSide.makeVisible();
        division.makeVisible();
    }
    
    /**
     * Hace invisible el tablero y sus elementos.
     */
    public void makeInvisible() {
        leftBorder.makeInvisible();
        rightBorder.makeInvisible();
        leftSide.makeInvisible();
        rightSide.makeInvisible();
        division.makeInvisible();
    }
    
    /**
     * Obtiene el límite superior del tablero.
     * @return Coordenada Y del límite superior.
     */
    public int getTopLimit() {
        return 0; // El techo del tablero está en la coordenada Y = 0.
    }

    /**
     * Obtiene el límite inferior del tablero.
     * @return Coordenada Y del límite inferior.
     */
    public int getBottomLimit() {
        return height; // El suelo del tablero está en la altura máxima del tablero.
    }
}
